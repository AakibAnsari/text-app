import React from "react";

export default function Footer() {
  return (
    <>
      <nav className="navbar scrollable-bottom bg-light">
        <div className="container-fluid">
            Copyright @ 2022 | Md Aakib Ansari
        </div>
      </nav>
    </>
  );
}
